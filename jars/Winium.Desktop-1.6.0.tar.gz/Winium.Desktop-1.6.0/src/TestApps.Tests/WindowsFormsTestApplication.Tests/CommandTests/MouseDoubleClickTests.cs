﻿namespace WindowsFormsTestApplication.Tests.CommandTests
{
    #region using

    using NUnit.Framework;

    #endregion

    public class MouseDoubleClickTests : BaseTest
    {
        #region Public Methods and Operators

        [Test]
        [Ignore("Application not have needed elements")]
        public void ClickToButton()
        {
            // TODO: Extend WindowsFormsTestApplication
        }

        #endregion
    }
}

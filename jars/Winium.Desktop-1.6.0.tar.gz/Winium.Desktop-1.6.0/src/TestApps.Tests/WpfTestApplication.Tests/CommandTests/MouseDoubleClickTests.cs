﻿namespace WpfTestApplication.Tests.CommandTests
{
    #region using

    using NUnit.Framework;

    using OpenQA.Selenium.Remote;

    #endregion

    public class MouseDoubleClickTests : BaseTest<RemoteWebDriver>
    {
        #region Public Methods and Operators

        [Test]
        [Ignore("Application not have needed elements")]
        public void ClickToButton()
        {
            // TODO: Extend WpfTestApplication
        }

        #endregion
    }
}

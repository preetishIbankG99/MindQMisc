.. _web_server:

Web Server
##########

Bugzilla requires a web server. It supports the following:

.. toctree::
   :maxdepth: 1

   apache
   apache-windows
   iis
   nginx
